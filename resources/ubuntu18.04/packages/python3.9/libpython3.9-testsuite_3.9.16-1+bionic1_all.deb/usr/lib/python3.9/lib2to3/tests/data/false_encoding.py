#! /usr/bin/python3.9
print '#coding=0'
